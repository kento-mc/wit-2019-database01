# wit-2019-database01
MySQL assignment modeling a hospital database

I have included 3 files.
I included the original HospitalSetup.sql file from which I created the database, as well as the export file just named Hospital.sql. And then finally there is the HopitalQueries.sql file with all the other queries and statements.
